##
## This script is sourced by /data/data/com.cs.ide/files/usr/bin/login before executing shell.
##
